<?php return array (
  'lifetime' => 0,
  'data' => 
  array (
    'nextDay1' => 'Thu 23.Mar',
    'nextDay2' => 'Fri 24.Mar',
    'nextDay3' => 'Sat 25.Mar',
    'nextDay4' => 'Sun 26.Mar',
    'markNextDay1' => true,
    'markNextDay2' => false,
    'markNextDay3' => true,
    'markNextDay4' => false,
  ),
);