<?php
/**
 * Created by PhpStorm.
 * User: markus
 * Date: 9.03.17
 * Time: 11:40
 */
define('BASE_URL', '/');

define('REAL_PATH', dirname(realpath('index.php')) . '/../');
