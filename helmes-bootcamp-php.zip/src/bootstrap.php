<?php
// Load dependencies from composer
require_once "../vendor/autoload.php";

// Load configuration
require_once 'Config/application.php';

// Load database connection params
require_once 'Config/database.php';